"""Database module for Quiz Bot"""

from .mongo import MongoDB

__all__ = ['MongoDB']