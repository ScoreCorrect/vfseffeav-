"""
MongoDB connection and helper functions for the Quiz Bot
Handles all database operations
"""

import logging
from pymongo import MongoClient
from pymongo.errors import ServerSelectionTimeoutError, ConnectionFailure
from config import MONGO_URI, DB_NAME
from datetime import datetime

logger = logging.getLogger(__name__)


class MongoDBError(Exception):
    """Custom exception for MongoDB operations"""
    pass


class MongoDB:
    """
    MongoDB database manager for the Quiz Bot.
    Handles connection, initialization, and common operations.
    """
    
    def __init__(self, uri: str = MONGO_URI, db_name: str = DB_NAME):
        """
        Initialize MongoDB connection
        
        Args:
            uri: MongoDB connection string
            db_name: Database name
        """
        self.uri = uri
        self.db_name = db_name
        self.client = None
        self.db = None
        self._connect()
    
    def _connect(self) -> None:
        """Establish connection to MongoDB"""
        try:
            self.client = MongoClient(self.uri, serverSelectionTimeoutMS=5000)
            # Verify connection
            self.client.admin.command('ping')
            self.db = self.client[self.db_name]
            logger.info(f"✓ Connected to MongoDB: {self.db_name}")
            self._initialize_collections()
        except (ServerSelectionTimeoutError, ConnectionFailure) as e:
            logger.error(f"✗ Failed to connect to MongoDB: {e}")
            raise MongoDBError(f"Failed to connect to MongoDB: {e}")
    
    def _initialize_collections(self) -> None:
        """Create collections if they don't exist"""
        required_collections = [
            'users',
            'topics',
            'quizzes',
            'participations',
            'leaderboard'
        ]
        
        existing = self.db.list_collection_names()
        for collection in required_collections:
            if collection not in existing:
                self.db.create_collection(collection)
                logger.info(f"✓ Created collection: {collection}")
            
            # Create indexes for better query performance
            self._create_indexes(collection)
    
    def _create_indexes(self, collection_name: str) -> None:
        """Create indexes for specific collections"""
        col = self.db[collection_name]
        
        if collection_name == 'users':
            col.create_index('user_id', unique=True)
            col.create_index('username')
        
        elif collection_name == 'topics':
            col.create_index('topic_id', unique=True)
            col.create_index('created_by')
        
        elif collection_name == 'quizzes':
            col.create_index('quiz_id', unique=True)
            col.create_index('topic_id')
            col.create_index('created_by')
        
        elif collection_name == 'participations':
            col.create_index('participation_id', unique=True)
            col.create_index([('user_id', 1), ('quiz_id', 1)])
            col.create_index('topic_id')
        
        elif collection_name == 'leaderboard':
            col.create_index('user_id', unique=True)
    
    # ===== USERS =====
    
    def create_user(self, user_id: int, username: str, is_verified: bool = False) -> dict:
        """Create a new user"""
        user = {
            'user_id': user_id,
            'username': username,
            'is_verified': is_verified,
            'created_at': datetime.utcnow(),
            'stats': {
                'total_quizzes': 0,
                'correct_answers': 0,
                'total_questions': 0
            }
        }
        self.db.users.insert_one(user)
        logger.info(f"✓ Created user: {username} ({user_id})")
        return user
    
    def get_user(self, user_id: int) -> dict:
        """Retrieve user by ID"""
        return self.db.users.find_one({'user_id': user_id})
    
    def user_exists(self, user_id: int) -> bool:
        """Check if user exists"""
        return self.db.users.find_one({'user_id': user_id}) is not None
    
    def is_user_verified(self, user_id: int) -> bool:
        """Check if user is verified"""
        user = self.get_user(user_id)
        return user.get('is_verified', False) if user else False
    
    # ===== TOPICS =====
    
    def create_topic(self, topic_id: str, topic_name: str, created_by: int) -> dict:
        """Create a new topic"""
        topic = {
            'topic_id': topic_id,
            'topic_name': topic_name,
            'created_by': created_by,
            'created_at': datetime.utcnow(),
            'question_count': 0,
            'description': ''
        }
        self.db.topics.insert_one(topic)
        logger.info(f"✓ Created topic: {topic_name}")
        return topic
    
    def get_topic(self, topic_id: str) -> dict:
        """Retrieve topic by ID"""
        return self.db.topics.find_one({'topic_id': topic_id})
    
    def get_topic_by_name(self, topic_name: str) -> dict:
        """Retrieve topic by name"""
        return self.db.topics.find_one({'topic_name': topic_name})
    
    def get_all_topics(self) -> list:
        """Get all topics"""
        return list(self.db.topics.find({}, {'_id': 0}))
    
    def topic_exists(self, topic_name: str) -> bool:
        """Check if topic exists by name"""
        return self.db.topics.find_one({'topic_name': topic_name}) is not None
    
    # ===== QUIZZES =====
    
    def create_quiz(self, quiz_id: str, topic_id: str, question: str, 
                   options: list, correct_answer: str, created_by: int) -> dict:
        """Create a new quiz question"""
        quiz = {
            'quiz_id': quiz_id,
            'topic_id': topic_id,
            'question': question,
            'options': options,
            'correct_answer': correct_answer,
            'created_by': created_by,
            'created_at': datetime.utcnow(),
            'difficulty': 'medium',
            'explanation': ''
        }
        self.db.quizzes.insert_one(quiz)
        
        # Update topic question count
        self.db.topics.update_one(
            {'topic_id': topic_id},
            {'$inc': {'question_count': 1}}
        )
        logger.info(f"✓ Created quiz question in topic: {topic_id}")
        return quiz
    
    def get_quiz(self, quiz_id: str) -> dict:
        """Retrieve quiz by ID"""
        return self.db.quizzes.find_one({'quiz_id': quiz_id})
    
    def get_quizzes_by_topic(self, topic_id: str) -> list:
        """Get all quizzes for a topic"""
        return list(self.db.quizzes.find({'topic_id': topic_id}, {'_id': 0}))
    
    def get_unanswered_quizzes(self, user_id: int, topic_id: str) -> list:
        """Get quizzes not yet answered by user in a topic"""
        answered_quizzes = self.db.participations.find(
            {'user_id': user_id, 'topic_id': topic_id},
            {'quiz_id': 1}
        )
        answered_ids = [p['quiz_id'] for p in answered_quizzes]
        
        return list(self.db.quizzes.find(
            {'topic_id': topic_id, 'quiz_id': {'$nin': answered_ids}},
            {'_id': 0}
        ))
    
    # ===== PARTICIPATIONS =====
    
    def record_participation(self, user_id: int, quiz_id: str, topic_id: str, 
                            is_correct: bool, time_taken: int = 0) -> dict:
        """Record user's quiz participation"""
        participation = {
            'participation_id': f"{user_id}_{quiz_id}_{datetime.utcnow().timestamp()}",
            'user_id': user_id,
            'quiz_id': quiz_id,
            'topic_id': topic_id,
            'is_correct': is_correct,
            'time_taken': time_taken,
            'timestamp': datetime.utcnow()
        }
        self.db.participations.insert_one(participation)
        
        # Update user stats
        self._update_user_stats(user_id, is_correct)
        
        logger.info(f"✓ Recorded participation: User {user_id}, Quiz {quiz_id}")
        return participation
    
    def _update_user_stats(self, user_id: int, is_correct: bool) -> None:
        """Update user statistics"""
        self.db.users.update_one(
            {'user_id': user_id},
            {
                '$inc': {
                    'stats.total_questions': 1,
                    'stats.correct_answers': 1 if is_correct else 0
                }
            }
        )
    
    def get_user_history(self, user_id: int, topic_id: str = None) -> list:
        """Get user's quiz history"""
        query = {'user_id': user_id}
        if topic_id:
            query['topic_id'] = topic_id
        
        return list(self.db.participations.find(query, {'_id': 0}))
    
    def get_user_topic_stats(self, user_id: int, topic_id: str) -> dict:
        """Get user's stats for a specific topic"""
        participations = self.get_user_history(user_id, topic_id)
        if not participations:
            return {'correct': 0, 'total': 0, 'accuracy': 0}
        
        correct = sum(1 for p in participations if p.get('is_correct'))
        total = len(participations)
        accuracy = (correct / total * 100) if total > 0 else 0
        
        return {
            'correct': correct,
            'total': total,
            'accuracy': round(accuracy, 2)
        }
    
    # ===== LEADERBOARD =====
    
    def update_leaderboard(self, user_id: int) -> None:
        """Update leaderboard entry for user"""
        user = self.get_user(user_id)
        if not user:
            return
        
        stats = user.get('stats', {})
        total = stats.get('total_questions', 0)
        correct = stats.get('correct_answers', 0)
        accuracy = (correct / total * 100) if total > 0 else 0
        
        leaderboard_entry = {
            'user_id': user_id,
            'username': user.get('username', 'Unknown'),
            'total_correct': correct,
            'total_attempted': total,
            'accuracy_percentage': round(accuracy, 2),
            'last_updated': datetime.utcnow()
        }
        
        self.db.leaderboard.update_one(
            {'user_id': user_id},
            {'$set': leaderboard_entry},
            upsert=True
        )
    
    def get_leaderboard(self, limit: int = 10) -> list:
        """Get top users from leaderboard"""
        return list(self.db.leaderboard.find({}).sort('accuracy_percentage', -1).limit(limit))
    
    def get_user_rank(self, user_id: int) -> int:
        """Get user's rank in leaderboard"""
        user_entry = self.db.leaderboard.find_one({'user_id': user_id})
        if not user_entry:
            return 0
        
        rank = self.db.leaderboard.count_documents(
            {'accuracy_percentage': {'$gt': user_entry['accuracy_percentage']}}
        ) + 1
        return rank
    
    # ===== CONNECTION =====
    
    def close(self) -> None:
        """Close MongoDB connection"""
        if self.client:
            self.client.close()
            logger.info("✓ Closed MongoDB connection")