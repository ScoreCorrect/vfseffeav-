"""
User history and statistics - View quiz history and performance
"""

import logging
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import Application, CommandHandler, CallbackQueryHandler, ContextTypes
from utils.keyboard import get_back_button, add_back_button
from db.mongo import MongoDB

logger = logging.getLogger(__name__)

db = None


async def history_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """
    Handle /history command - Show user's quiz history
    
    Args:
        update: Telegram update
        context: Callback context
    """
    user_id = update.effective_user.id
    
    history = db.get_user_history(user_id) if db else []
    
    if not history:
        await update.message.reply_text(
            "📭 You haven't attempted any quizzes yet.\n\n"
            "Start taking quizzes to build your history!",
            reply_markup=get_back_button()
        )
        return
    
    # Show last 10 attempts
    recent_history = history[-10:]
    
    text = "📋 **Your Quiz History** (Last 10 attempts)\n\n"
    for i, attempt in enumerate(recent_history, 1):
        status = "✅" if attempt.get('is_correct') else "❌"
        text += f"{i}. {status} Quiz ID: {attempt.get('quiz_id', 'N/A')}\n"
    
    await update.message.reply_text(
        text,
        reply_markup=get_back_button(),
        parse_mode='Markdown'
    )


async def stats_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """
    Handle /stats command - Show user's statistics
    
    Args:
        update: Telegram update
        context: Callback context
    """
    user_id = update.effective_user.id
    
    user = db.get_user(user_id) if db else None
    
    if not user:
        await update.message.reply_text(
            "👤 User profile not found.",
            reply_markup=get_back_button()
        )
        return
    
    stats = user.get('stats', {})
    total_questions = stats.get('total_questions', 0)
    correct_answers = stats.get('correct_answers', 0)
    
    if total_questions == 0:
        accuracy = 0
    else:
        accuracy = (correct_answers / total_questions) * 100
    
    rank = db.get_user_rank(user_id) if db else 0
    
    text = (
        f"📊 **Your Statistics**\n\n"
        f"👤 User: {user.get('username', 'Unknown')}\n"
        f"📝 Total Questions Answered: {total_questions}\n"
        f"✅ Correct Answers: {correct_answers}\n"
        f"❌ Wrong Answers: {total_questions - correct_answers}\n"
        f"🎯 Accuracy: {accuracy:.1f}%\n"
        f"🏆 Leaderboard Rank: {'#' + str(rank) if rank > 0 else 'Not ranked'}"
    )
    
    await update.message.reply_text(
        text,
        reply_markup=get_back_button(),
        parse_mode='Markdown'
    )


async def history_callback(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """
    Handle history button callback
    
    Args:
        update: Telegram update
        context: Callback context
    """
    query = update.callback_query
    await query.answer()
    
    user_id = update.effective_user.id
    history = db.get_user_history(user_id) if db else []
    
    if not history:
        await query.edit_message_text(
            "📭 You haven't attempted any quizzes yet.",
            reply_markup=get_back_button()
        )
        return
    
    recent_history = history[-10:]
    text = "📋 **Your Quiz History**\n\n"
    for i, attempt in enumerate(recent_history, 1):
        status = "✅" if attempt.get('is_correct') else "❌"
        text += f"{i}. {status}\n"
    
    await query.edit_message_text(
        text,
        reply_markup=get_back_button(),
        parse_mode='Markdown'
    )


async def stats_callback(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """
    Handle stats button callback
    
    Args:
        update: Telegram update
        context: Callback context
    """
    query = update.callback_query
    await query.answer()
    
    user_id = update.effective_user.id
    user = db.get_user(user_id) if db else None
    
    if not user:
        await query.edit_message_text(
            "👤 User profile not found.",
            reply_markup=get_back_button()
        )
        return
    
    stats = user.get('stats', {})
    total_questions = stats.get('total_questions', 0)
    correct_answers = stats.get('correct_answers', 0)
    accuracy = (correct_answers / total_questions * 100) if total_questions > 0 else 0
    rank = db.get_user_rank(user_id) if db else 0
    
    text = (
        f"📊 **Your Statistics**\n\n"
        f"📝 Total Questions: {total_questions}\n"
        f"✅ Correct: {correct_answers}\n"
        f"🎯 Accuracy: {accuracy:.1f}%\n"
        f"🏆 Rank: {'#' + str(rank) if rank > 0 else 'N/A'}"
    )
    
    await query.edit_message_text(
        text,
        reply_markup=get_back_button(),
        parse_mode='Markdown'
    )


def setup(app: Application) -> None:
    """
    Register handlers for history plugin
    
    Args:
        app: Telegram Application instance
    """
    global db
    if hasattr(app, '_db_instance'):
        db = app._db_instance
    
    app.add_handler(CommandHandler('history', history_command))
    app.add_handler(CommandHandler('stats', stats_command))
    app.add_handler(CallbackQueryHandler(history_callback, pattern='^history$'))
    app.add_handler(CallbackQueryHandler(stats_callback, pattern='^stats$'))