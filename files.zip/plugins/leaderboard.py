"""
Leaderboard functionality - View rankings and user performance
"""

import logging
from telegram import Update
from telegram.ext import Application, CommandHandler, CallbackQueryHandler, ContextTypes
from utils.keyboard import get_back_button
from db.mongo import MongoDB

logger = logging.getLogger(__name__)

db = None


async def leaderboard_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """
    Handle /leaderboard command - Show top performers
    
    Args:
        update: Telegram update
        context: Callback context
    """
    leaderboard = db.get_leaderboard(limit=10) if db else []
    
    if not leaderboard:
        await update.message.reply_text(
            "📭 Leaderboard is empty. Start taking quizzes!",
            reply_markup=get_back_button()
        )
        return
    
    text = "🏆 **Top 10 Performers** 🏆\n\n"
    for rank, entry in enumerate(leaderboard, 1):
        text += (
            f"{rank}. {entry.get('username', 'Unknown')}\n"
            f"   ✅ {entry.get('total_correct', 0)} / {entry.get('total_attempted', 0)}\n"
            f"   🎯 {entry.get('accuracy_percentage', 0)}%\n\n"
        )
    
    await update.message.reply_text(
        text,
        reply_markup=get_back_button(),
        parse_mode='Markdown'
    )


async def leaderboard_callback(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """
    Handle leaderboard button callback
    
    Args:
        update: Telegram update
        context: Callback context
    """
    query = update.callback_query
    await query.answer()
    
    leaderboard = db.get_leaderboard(limit=10) if db else []
    
    if not leaderboard:
        await query.edit_message_text(
            "📭 Leaderboard is empty.",
            reply_markup=get_back_button()
        )
        return
    
    text = "🏆 **Top 10 Performers**\n\n"
    for rank, entry in enumerate(leaderboard, 1):
        text += (
            f"{rank}. {entry.get('username', 'Unknown')} "
            f"({entry.get('accuracy_percentage', 0)}%)\n"
        )
    
    await query.edit_message_text(
        text,
        reply_markup=get_back_button(),
        parse_mode='Markdown'
    )


def setup(app: Application) -> None:
    """
    Register handlers for leaderboard plugin
    
    Args:
        app: Telegram Application instance
    """
    global db
    if hasattr(app, '_db_instance'):
        db = app._db_instance
    
    app.add_handler(CommandHandler('leaderboard', leaderboard_command))
    app.add_handler(CallbackQueryHandler(leaderboard_callback, pattern='^leaderboard$'))