"""
/start command handler and main menu navigation
"""

import logging
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import Application, CommandHandler, CallbackQueryHandler, ContextTypes
from config import BOT_WELCOME_MESSAGE
from utils.keyboard import get_main_menu_keyboard
from db.mongo import MongoDB

logger = logging.getLogger(__name__)

# Initialize DB (shared instance from main.py)
db = None


async def start_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """
    Handle /start command
    
    Args:
        update: Telegram update
        context: Callback context
    """
    user = update.effective_user
    chat_id = update.effective_chat.id
    
    logger.info(f"👤 User started bot: {user.username} ({user.id})")
    
    # Create user in database if doesn't exist
    if db and not db.user_exists(user.id):
        db.create_user(user.id, user.username or "Unknown")
    
    # Send welcome message with main menu
    welcome_text = f"{BOT_WELCOME_MESSAGE}\n\n👤 Welcome, {user.first_name}!"
    
    await context.bot.send_message(
        chat_id=chat_id,
        text=welcome_text,
        reply_markup=get_main_menu_keyboard()
    )


async def main_menu_callback(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """
    Handle main menu button callback
    
    Args:
        update: Telegram update
        context: Callback context
    """
    query = update.callback_query
    await query.answer()
    
    await query.edit_message_text(
        text=BOT_WELCOME_MESSAGE,
        reply_markup=get_main_menu_keyboard()
    )


async def back_callback(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """
    Handle back button callback - return to main menu
    
    Args:
        update: Telegram update
        context: Callback context
    """
    query = update.callback_query
    await query.answer()
    
    await query.edit_message_text(
        text=BOT_WELCOME_MESSAGE,
        reply_markup=get_main_menu_keyboard()
    )


def setup(app: Application) -> None:
    """
    Register handlers for start plugin
    
    Args:
        app: Telegram Application instance
    """
    global db
    # Get the shared DB instance
    if hasattr(app, '_db_instance'):
        db = app._db_instance
    
    app.add_handler(CommandHandler('start', start_command))
    app.add_handler(CallbackQueryHandler(main_menu_callback, pattern='^main_menu$'))
    app.add_handler(CallbackQueryHandler(back_callback, pattern='^back$'))