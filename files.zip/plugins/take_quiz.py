"""
Quiz taking functionality - Users select topics and answer questions
"""

import logging
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import (
    Application, CommandHandler, CallbackQueryHandler, 
    MessageHandler, filters, ContextTypes, ConversationHandler
)
from utils.keyboard import get_back_button, create_topics_keyboard, create_options_keyboard
from db.mongo import MongooDB

logger = logging.getLogger(__name__)

db = None

# Conversation states
TOPIC_SELECTION, ANSWERING_QUIZ = range(2)


async def quiz_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    """
    Handle /quiz command - Start quiz selection
    
    Args:
        update: Telegram update
        context: Callback context
    
    Returns:
        Conversation state
    """
    return await show_topics(update, context)


async def quiz_callback(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    """
    Handle quiz button from main menu
    
    Args:
        update: Telegram update
        context: Callback context
    
    Returns:
        Conversation state
    """
    query = update.callback_query
    await query.answer()
    return await show_topics(update, context)


async def show_topics(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    """
    Show all available topics for quiz selection
    
    Args:
        update: Telegram update
        context: Callback context
    
    Returns:
        Conversation state
    """
    query = update.callback_query if update.callback_query else None
    
    # Get all topics
    topics = db.get_all_topics() if db else []
    
    if not topics:
        text = "❌ No topics available yet. Check back later!"
        if query:
            await query.edit_message_text(text, reply_markup=get_back_button())
        else:
            await update.message.reply_text(text, reply_markup=get_back_button())
        return ConversationHandler.END
    
    keyboard = create_topics_keyboard(topics).inline_keyboard
    
    text = "📚 **Select a Topic**\n\nChoose a topic to start practicing:"
    
    if query:
        await query.edit_message_text(text, reply_markup=InlineKeyboardMarkup(keyboard), parse_mode='Markdown')
    else:
        await update.message.reply_text(text, reply_markup=InlineKeyboardMarkup(keyboard), parse_mode='Markdown')
    
    return TOPIC_SELECTION


async def topic_selected(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    """
    Handle topic selection and show first question
    
    Args:
        update: Telegram update
        context: Callback context
    
    Returns:
        Conversation state
    """
    query = update.callback_query
    await query.answer()
    
    topic_id = query.data.replace('topic_', '')
    context.user_data['topic_id'] = topic_id
    context.user_data['quiz_index'] = 0
    context.user_data['correct_count'] = 0
    context.user_data['total_count'] = 0
    
    return await show_next_question(update, context)


async def show_next_question(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    """
    Show next unanswered question from selected topic
    
    Args:
        update: Telegram update
        context: Callback context
    
    Returns:
        Conversation state
    """
    user_id = update.effective_user.id
    topic_id = context.user_data.get('topic_id')
    
    # Get unanswered quizzes
    quizzes = db.get_unanswered_quizzes(user_id, topic_id) if db else []
    
    if not quizzes:
        # Quiz completed
        return await show_quiz_result(update, context)
    
    # Get first unanswered quiz
    current_quiz = quizzes[0]
    context.user_data['current_quiz'] = current_quiz
    context.user_data['total_count'] += 1
    
    question = current_quiz.get('question', 'No question')
    options = current_quiz.get('options', [])
    quiz_id = current_quiz.get('quiz_id')
    
    keyboard = create_options_keyboard(options, quiz_id).inline_keyboard
    
    text = f"📝 **Question {context.user_data['quiz_index'] + 1}**\n\n{question}"
    
    query = update.callback_query if update.callback_query else None
    if query:
        await query.edit_message_text(text, reply_markup=InlineKeyboardMarkup(keyboard), parse_mode='Markdown')
    else:
        await update.message.reply_text(text, reply_markup=InlineKeyboardMarkup(keyboard), parse_mode='Markdown')
    
    context.user_data['quiz_index'] += 1
    
    return ANSWERING_QUIZ


async def answer_given(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    """
    Handle answer submission
    
    Args:
        update: Telegram update
        context: Callback context
    
    Returns:
        Conversation state
    """
    query = update.callback_query
    await query.answer()
    
    # Parse callback data
    callback_data = query.data
    if callback_data.startswith('answer_'):
        parts = callback_data.split('_')
        quiz_id = '_'.join(parts[1:-1])  # Handle UUIDs with underscores
        option_index = int(parts[-1])
    else:
        return ANSWERING_QUIZ
    
    current_quiz = context.user_data.get('current_quiz', {})
    correct_answer = current_quiz.get('correct_answer')
    options = current_quiz.get('options', [])
    selected_answer = options[option_index] if option_index < len(options) else None
    
    is_correct = selected_answer == correct_answer
    user_id = update.effective_user.id
    topic_id = context.user_data.get('topic_id')
    
    # Record participation
    if db:
        db.record_participation(user_id, quiz_id, topic_id, is_correct)
    
    if is_correct:
        context.user_data['correct_count'] += 1
        result_text = "✅ **Correct!**"
    else:
        result_text = f"❌ **Wrong!**\n\nCorrect answer: {correct_answer}"
    
    result_text += "\n\nLoading next question..."
    
    await query.edit_message_text(result_text)
    
    # Show next question
    return await show_next_question(update, context)


async def stop_quiz(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    """
    Handle /stop command to end quiz
    
    Args:
        update: Telegram update
        context: Callback context
    
    Returns:
        Conversation state
    """
    query = update.callback_query
    if query:
        await query.answer()
    
    return await show_quiz_result(update, context)


async def show_quiz_result(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    """
    Show quiz results and statistics
    
    Args:
        update: Telegram update
        context: Callback context
    
    Returns:
        Conversation state
    """
    user_id = update.effective_user.id
    topic_id = context.user_data.get('topic_id')
    correct_count = context.user_data.get('correct_count', 0)
    total_count = context.user_data.get('total_count', 0)
    
    if total_count == 0:
        result_text = "No questions answered."
    else:
        accuracy = (correct_count / total_count) * 100
        result_text = (
            f"📊 **Quiz Results**\n\n"
            f"✅ Correct: {correct_count}/{total_count}\n"
            f"❌ Wrong: {total_count - correct_count}/{total_count}\n"
            f"🎯 Accuracy: {accuracy:.1f}%"
        )
        
        # Update leaderboard
        if db:
            db.update_leaderboard(user_id)
    
    keyboard = InlineKeyboardMarkup([
        [InlineKeyboardButton("📚 Take Another Quiz", callback_data='quiz')],
        [InlineKeyboardButton("⬅️ Back", callback_data='back')]
    ])
    
    query = update.callback_query if update.callback_query else None
    if query:
        await query.edit_message_text(result_text, reply_markup=keyboard, parse_mode='Markdown')
    else:
        await update.message.reply_text(result_text, reply_markup=keyboard, parse_mode='Markdown')
    
    return ConversationHandler.END


def setup(app: Application) -> None:
    """
    Register handlers for take quiz plugin
    
    Args:
        app: Telegram Application instance
    """
    global db
    if hasattr(app, '_db_instance'):
        db = app._db_instance
    
    quiz_handler = ConversationHandler(
        entry_points=[
            CommandHandler('quiz', quiz_command),
            CallbackQueryHandler(quiz_callback, pattern='^quiz$')
        ],
        states={
            TOPIC_SELECTION: [
                CallbackQueryHandler(topic_selected, pattern='^topic_')
            ],
            ANSWERING_QUIZ: [
                CallbackQueryHandler(answer_given, pattern='^answer_'),
                CallbackQueryHandler(stop_quiz, pattern='^stop_quiz$')
            ]
        },
        fallbacks=[CallbackQueryHandler(lambda u, c: ConversationHandler.END, pattern='^back$')]
    )
    
    app.add_handler(quiz_handler)