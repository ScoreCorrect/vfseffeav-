"""
Add quiz questions and manage topics (for verified users only)
"""

import logging
import uuid
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import (
    Application, CommandHandler, CallbackQueryHandler, 
    MessageHandler, filters, ContextTypes, ConversationHandler
)
from utils.keyboard import get_back_button, add_back_button
from utils.permissions import check_permission
from db.mongo import MongoDB

logger = logging.getLogger(__name__)

db = None

# Conversation states
TOPIC_SELECTION, QUESTION_INPUT, OPTIONS_INPUT, ANSWER_INPUT = range(4)


async def add_quiz_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    """
    Handle /add_quiz command - only for verified users
    
    Args:
        update: Telegram update
        context: Callback context
    
    Returns:
        Conversation state
    """
    user_id = update.effective_user.id
    
    if not check_permission(user_id, 'verified'):
        await update.message.reply_text(
            "❌ You don't have permission to add quizzes. "
            "Only verified users can add quizzes.",
            reply_markup=get_back_button()
        )
        return ConversationHandler.END
    
    return await show_topic_selection(update, context)


async def add_quiz_callback(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    """
    Handle add quiz button callback
    
    Args:
        update: Telegram update
        context: Callback context
    
    Returns:
        Conversation state
    """
    user_id = update.effective_user.id
    query = update.callback_query
    
    if not check_permission(user_id, 'verified'):
        await query.answer("❌ You don't have permission to add quizzes!", show_alert=True)
        return ConversationHandler.END
    
    await query.answer()
    return await show_topic_selection(update, context)


async def show_topic_selection(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    """
    Show existing topics or option to create new one
    
    Args:
        update: Telegram update
        context: Callback context
    
    Returns:
        Conversation state
    """
    query = update.callback_query if update.callback_query else None
    
    # Get all topics
    topics = db.get_all_topics() if db else []
    
    # Create keyboard with existing topics
    keyboard = [
        [InlineKeyboardButton(topic['topic_name'], 
                            callback_data=f"select_topic_{topic['topic_id']}")]
        for topic in topics
    ]
    
    # Add "New Topic" button
    keyboard.append([InlineKeyboardButton("➕ Create New Topic", 
                                         callback_data='create_new_topic')])
    
    keyboard = add_back_button(keyboard).inline_keyboard
    
    text = "📚 **Select a topic or create a new one:**\n\nChoose a topic from the list below or create a new topic."
    
    if query:
        await query.edit_message_text(text, reply_markup=InlineKeyboardMarkup(keyboard), parse_mode='Markdown')
    else:
        await update.message.reply_text(text, reply_markup=InlineKeyboardMarkup(keyboard), parse_mode='Markdown')
    
    return TOPIC_SELECTION


async def topic_selected(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    """
    Handle topic selection
    
    Args:
        update: Telegram update
        context: Callback context
    
    Returns:
        Conversation state
    """
    query = update.callback_query
    await query.answer()
    
    topic_id = query.data.replace('select_topic_', '')
    context.user_data['topic_id'] = topic_id
    
    topic = db.get_topic(topic_id) if db else None
    
    text = f"📝 **Add Question to Topic: {topic.get('topic_name', 'Unknown') if topic else 'Unknown'}**\n\n" \
           f"Send the question text:"
    
    await query.edit_message_text(text, parse_mode='Markdown')
    
    return QUESTION_INPUT


async def new_topic_input(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    """
    Handle new topic creation
    
    Args:
        update: Telegram update
        context: Callback context
    
    Returns:
        Conversation state
    """
    query = update.callback_query
    await query.answer()
    
    await query.edit_message_text(
        "📝 Enter the name for the new topic:",
        reply_markup=get_back_button()
    )
    
    context.user_data['creating_new_topic'] = True
    return TOPIC_SELECTION


async def question_input(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    """
    Handle question text input
    
    Args:
        update: Telegram update
        context: Callback context
    
    Returns:
        Conversation state
    """
    # If creating new topic
    if context.user_data.get('creating_new_topic'):
        topic_name = update.message.text
        user_id = update.effective_user.id
        topic_id = str(uuid.uuid4())
        
        if db:
            db.create_topic(topic_id, topic_name, user_id)
        context.user_data['topic_id'] = topic_id
        context.user_data['creating_new_topic'] = False
    
    question_text = update.message.text
    context.user_data['question'] = question_text
    
    await update.message.reply_text(
        "📋 Now send the answer options (separate each option with a comma):\n"
        "Example: Option 1, Option 2, Option 3, Option 4",
        reply_markup=get_back_button()
    )
    
    return OPTIONS_INPUT


async def options_input(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    """
    Handle options input
    
    Args:
        update: Telegram update
        context: Callback context
    
    Returns:
        Conversation state
    """
    options_text = update.message.text
    options = [opt.strip() for opt in options_text.split(',')]
    context.user_data['options'] = options
    
    # Create options keyboard for answer selection
    keyboard = [
        [InlineKeyboardButton(f"{i+1}. {opt}", callback_data=f"correct_ans_{i}")]
        for i, opt in enumerate(options)
    ]
    keyboard = add_back_button(keyboard).inline_keyboard
    
    await update.message.reply_text(
        "✅ Which one is the correct answer?",
        reply_markup=InlineKeyboardMarkup(keyboard)
    )
    
    return ANSWER_INPUT


async def answer_selected(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    """
    Handle correct answer selection and save quiz
    
    Args:
        update: Telegram update
        context: Callback context
    
    Returns:
        Conversation state
    """
    query = update.callback_query
    await query.answer()
    
    answer_index = int(query.data.replace('correct_ans_', ''))
    options = context.user_data.get('options', [])
    correct_answer = options[answer_index]
    
    # Save quiz to database
    if db:
        quiz_id = str(uuid.uuid4())
        db.create_quiz(
            quiz_id=quiz_id,
            topic_id=context.user_data.get('topic_id'),
            question=context.user_data.get('question'),
            options=options,
            correct_answer=correct_answer,
            created_by=update.effective_user.id
        )
    
    await query.edit_message_text(
        "✅ **Quiz question added successfully!**\n\n"
        "You can add more questions or return to the main menu.",
        reply_markup=InlineKeyboardMarkup([
            [InlineKeyboardButton("➕ Add Another Question", callback_data='add_quiz')],
            [InlineKeyboardButton("⬅️ Back", callback_data='back')]
        ])
    )
    
    return ConversationHandler.END


def setup(app: Application) -> None:
    """
    Register handlers for add quiz plugin
    
    Args:
        app: Telegram Application instance
    """
    global db
    if hasattr(app, '_db_instance'):
        db = app._db_instance
    
    add_quiz_handler = ConversationHandler(
        entry_points=[
            CommandHandler('add_quiz', add_quiz_command),
            CallbackQueryHandler(add_quiz_callback, pattern='^add_quiz$')
        ],
        states={
            TOPIC_SELECTION: [
                CallbackQueryHandler(topic_selected, pattern='^select_topic_'),
                CallbackQueryHandler(new_topic_input, pattern='^create_new_topic$'),
                MessageHandler(filters.TEXT & ~filters.COMMAND, question_input)
            ],
            QUESTION_INPUT: [
                MessageHandler(filters.TEXT & ~filters.COMMAND, question_input)
            ],
            OPTIONS_INPUT: [
                MessageHandler(filters.TEXT & ~filters.COMMAND, options_input)
            ],
            ANSWER_INPUT: [
                CallbackQueryHandler(answer_selected, pattern='^correct_ans_')
            ]
        },
        fallbacks=[CallbackQueryHandler(lambda u, c: ConversationHandler.END, pattern='^back$')]
    )
    
    app.add_handler(add_quiz_handler)