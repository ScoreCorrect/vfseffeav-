"""
/help command handler - Shows available commands and features
"""

import logging
from telegram import Update
from telegram.ext import Application, CommandHandler, CallbackQueryHandler, ContextTypes
from utils.keyboard import get_back_button

logger = logging.getLogger(__name__)

HELP_MESSAGE = """
❓ **HELP - Available Commands & Features**

🎯 **Main Commands:**
• /start - Start the bot and see main menu
• /help - Show this help message
• /history - View your quiz history
• /stats - View your statistics
• /leaderboard - See top performers

📝 **For All Users:**
• 📚 **Take Quiz** - Choose a topic and practice quizzes
• 🏆 **Leaderboard** - Compete with other users
• 📊 **Statistics** - View your performance metrics

➕ **For Verified Users:**
• **Add Quiz** - Create and add new quiz questions
• **Create Topics** - Create new quiz topics/subjects
• **Manage Topics** - Edit and manage quiz topics

⏹️ **During Quiz:**
• Send answers by clicking the options
• Use /stop command to end the quiz and see results
• Questions won't repeat if you've answered them correctly

💡 **How to Use:**
1. Select a topic from the available list
2. Answer questions one by one
3. Use /stop to finish and see your score
4. Check leaderboard to see how you rank
5. Review your history to see past performance

❓ **Questions?**
Contact the bot administrator for support.

Select an option below or go back to continue.
"""


async def help_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """
    Handle /help command
    
    Args:
        update: Telegram update
        context: Callback context
    """
    chat_id = update.effective_chat.id
    
    await context.bot.send_message(
        chat_id=chat_id,
        text=HELP_MESSAGE,
        parse_mode='Markdown',
        reply_markup=get_back_button()
    )


async def help_callback(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """
    Handle help button callback from main menu
    
    Args:
        update: Telegram update
        context: Callback context
    """
    query = update.callback_query
    await query.answer()
    
    await query.edit_message_text(
        text=HELP_MESSAGE,
        parse_mode='Markdown',
        reply_markup=get_back_button()
    )


def setup(app: Application) -> None:
    """
    Register handlers for help plugin
    
    Args:
        app: Telegram Application instance
    """
    app.add_handler(CommandHandler('help', help_command))
    app.add_handler(CallbackQueryHandler(help_callback, pattern='^help$'))