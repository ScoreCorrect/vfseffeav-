"""
State management for conversation flows
"""

from enum import Enum


class UserState(Enum):
    """User states in the bot conversation"""
    
    # Main states
    MAIN_MENU = 'main_menu'
    HELP = 'help'
    
    # Quiz taking states
    SELECTING_TOPIC = 'selecting_topic'
    TAKING_QUIZ = 'taking_quiz'
    QUIZ_RESULT = 'quiz_result'
    
    # Quiz creation states (for verified users)
    ADD_QUIZ_TOPIC = 'add_quiz_topic'
    ADD_QUIZ_QUESTION = 'add_quiz_question'
    ADD_QUIZ_OPTIONS = 'add_quiz_options'
    ADD_QUIZ_ANSWER = 'add_quiz_answer'
    
    # History/Analytics
    VIEWING_HISTORY = 'viewing_history'
    VIEWING_LEADERBOARD = 'viewing_leaderboard'
    VIEWING_STATS = 'viewing_stats'