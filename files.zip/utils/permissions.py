"""
Permission checking utilities for bot commands
"""

from config import VERIFIED_USERS, ADMIN_USERS


def is_verified_user(user_id: int) -> bool:
    """
    Check if user is verified (can add quizzes/topics)
    
    Args:
        user_id: Telegram user ID
    
    Returns:
        True if user is verified, False otherwise
    """
    return user_id in VERIFIED_USERS


def is_admin_user(user_id: int) -> bool:
    """
    Check if user is an admin
    
    Args:
        user_id: Telegram user ID
    
    Returns:
        True if user is admin, False otherwise
    """
    return user_id in ADMIN_USERS


def check_permission(user_id: int, required_level: str = 'user') -> bool:
    """
    Check if user has required permission level
    
    Args:
        user_id: Telegram user ID
        required_level: 'user', 'verified', or 'admin'
    
    Returns:
        True if user has permission, False otherwise
    """
    if required_level == 'admin':
        return is_admin_user(user_id)
    elif required_level == 'verified':
        return is_verified_user(user_id) or is_admin_user(user_id)
    else:  # 'user'
        return True