"""
Keyboard/Reply Markup utilities for consistent button layouts
"""

from telegram import InlineKeyboardButton, InlineKeyboardMarkup
from config import BACK_BUTTON_TEXT, MAIN_MENU_TEXT


def get_back_button() -> InlineKeyboardMarkup:
    """
    Get a simple back button layout
    
    Returns:
        InlineKeyboardMarkup with back button
    """
    keyboard = [
        [InlineKeyboardButton(BACK_BUTTON_TEXT, callback_data='back')]
    ]
    return InlineKeyboardMarkup(keyboard)


def get_main_menu_keyboard() -> InlineKeyboardMarkup:
    """
    Get main menu keyboard with Help and Add Quiz buttons
    
    Returns:
        InlineKeyboardMarkup with main menu buttons
    """
    keyboard = [
        [InlineKeyboardButton("❓ Help", callback_data='help')],
        [InlineKeyboardButton("➕ Add Quiz", callback_data='add_quiz')]
    ]
    return InlineKeyboardMarkup(keyboard)


def get_back_and_home_buttons() -> InlineKeyboardMarkup:
    """
    Get back and main menu buttons
    
    Returns:
        InlineKeyboardMarkup with back and home buttons
    """
    keyboard = [
        [
            InlineKeyboardButton(BACK_BUTTON_TEXT, callback_data='back'),
            InlineKeyboardButton(MAIN_MENU_TEXT, callback_data='main_menu')
        ]
    ]
    return InlineKeyboardMarkup(keyboard)


def add_back_button(keyboard: list) -> InlineKeyboardMarkup:
    """
    Add a back button to existing keyboard
    
    Args:
        keyboard: List of button rows
    
    Returns:
        InlineKeyboardMarkup with back button added
    """
    keyboard.append([InlineKeyboardButton(BACK_BUTTON_TEXT, callback_data='back')])
    return InlineKeyboardMarkup(keyboard)


def create_topics_keyboard(topics: list, add_back: bool = True) -> InlineKeyboardMarkup:
    """
    Create a keyboard with topic buttons
    
    Args:
        topics: List of topic dictionaries
        add_back: Whether to add a back button
    
    Returns:
        InlineKeyboardMarkup with topic buttons
    """
    keyboard = [
        [InlineKeyboardButton(topic.get('topic_name', topic), 
                            callback_data=f"topic_{topic.get('topic_id', topic)}")]
        for topic in topics
    ]
    
    if add_back:
        keyboard = add_back_button(keyboard).inline_keyboard
    
    return InlineKeyboardMarkup(keyboard)


def create_options_keyboard(options: list, quiz_id: str) -> InlineKeyboardMarkup:
    """
    Create a keyboard with quiz answer options
    
    Args:
        options: List of answer options
        quiz_id: ID of the quiz question
    
    Returns:
        InlineKeyboardMarkup with option buttons
    """
    keyboard = [
        [InlineKeyboardButton(option, callback_data=f"answer_{quiz_id}_{i}")]
        for i, option in enumerate(options)
    ]
    
    keyboard.append([InlineKeyboardButton("⏹️ Stop Quiz", callback_data='stop_quiz')])
    
    return InlineKeyboardMarkup(keyboard)